SELECT DISTINCT  user_birth FROM GGHJ_BOARD gb JOIN GGHJ_UNI GU
ON gb.USER_ID  = gu.User_ID 
JOIN GGHJ_USER gu2 ON gu2.USER_ID = gu.User_ID 
WHERE gu2.user_id = 1;


-- 조회수 게시판(정렬) --
   
SELECT -- 네모칸 안에 뜨는것만 -- 
    u.USER_NICKNAME, b.BOARD_TITLE , b.BOARD_TITLE  
FROM 
    GGHJ_BOARD b JOIN GGHJ_USER u
    ON u.user_id = b.USER_ID 
ORDER BY 
   BOARD_VIEW_COUNT DESC;

-- 최신 게시판(정렬) --
   
SELECT -- 네모칸 안에 뜨는것만 -- 
    u.USER_NICKNAME, b.BOARD_TITLE , b.BOARD_TITLE  
FROM 
    GGHJ_BOARD b JOIN GGHJ_USER u
    ON u.user_id = b.USER_ID 
ORDER BY 
   b.BOARD_CREATED_DATE DESC;

-- 인기 게시판(정렬) --

SELECT 
    u.USER_NICKNAME, b.BOARD_TITLE, b.BOARD_TITLE 
FROM 
    GGHJ_BOARD b JOIN GGHJ_USER u
    ON u.user_id = b.USER_ID 
ORDER BY 
    b.BOARD_LIKE_COUNT DESC;
   
-- 대댓글 내용, 대댓글 작성일 -- 
SELECT 
    c.COMMENT_CONTENT,
    r.REPLY_CONTENT,
    r.REPLY_CREATED_DATE
FROM 
    GGHJ_COMMENT c 
JOIN 
    GGHJ_REPLY r ON c.COMMENT_ID = r.COMMENT_ID;
   
-- Insert - 대댓글 작성
INSERT INTO GGHJ_REPLY (REPLY_ID, REPLY_CONTENT, REPLY_CREATED_DATE, COMMENT_ID)
VALUES (SEQ_REPLY.NEXTVAL, '안녕하세요', SYSDATE, 1);

-- Delete - 대댓글 삭제
-- DELETE FROM GGHJ_REPLY
-- WHERE REPLY_ID = ??

-- Insert - 대댓글 신고
INSERT INTO GGHJ_REPORT (REPORT_ID, REPORT_REASON, REPORT_CREATED_DATE, REPORT_COUNT, REPLY_ID)
VALUES (SEQ_REPORT.NEXTVAL, '바보', SYSDATE, 1, 2);

-- Update - 대댓글 신고
UPDATE GGHJ_REPORT
SET REPORT_REASON = '너 나쁜사람.'
WHERE REPORT_ID = 1;