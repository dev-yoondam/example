package com.example.geungeunhanjan.mapper.board;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface BoardCommentMapper {
}
