package com.example.geungeunhanjan;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GeungeunhanjanApplication {

    public static void main(String[] args) {
        SpringApplication.run(GeungeunhanjanApplication.class, args);
    }

}
